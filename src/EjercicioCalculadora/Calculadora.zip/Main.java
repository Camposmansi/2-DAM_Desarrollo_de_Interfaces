package EjercicioCalculadora;

public class Main {


    public static void main(String[] args) {
        VentanaCalculadora calculadora = new VentanaCalculadora();
        calculadora.setVisible(true);

    }
}

